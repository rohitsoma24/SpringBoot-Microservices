package com.mphasis;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

import com.mphasis.domain.Product;
import com.mphasis.repository.ProductRepository;

@EnableEurekaClient
@SpringBootApplication
public class StoreappApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(StoreappApplication.class, args);
	}

	@Autowired
	@Qualifier(value = "productRepository")
	private ProductRepository productRepository;

	@Override
	public void run(String... args) throws Exception {
		productRepository.save(new Product(null, "LG", 45454.0));
		productRepository.save(new Product(null, "Samsung", 35454.0));
		productRepository.save(new Product(null, "Dell", 27454.0));
		productRepository.save(new Product(null, "Apple", 75454.0));
		productRepository.save(new Product(null, "hp", 55454.0));
	}
}
