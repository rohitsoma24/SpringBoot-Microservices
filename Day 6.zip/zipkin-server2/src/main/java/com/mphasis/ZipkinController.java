package com.mphasis;

import java.util.logging.Logger;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ZipkinController {

	private static final Logger LOG = Logger.getLogger(ZipkinController.class.getName());

	@GetMapping(value = "/zipkin2")
	public String zipkinService1() {
		
		LOG.info("\nInside zipkinService 2..\n");

		return "Hi from zipkinService 2...";
	}
}
