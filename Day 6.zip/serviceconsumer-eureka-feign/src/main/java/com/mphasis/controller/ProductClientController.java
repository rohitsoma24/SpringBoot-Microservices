package com.mphasis.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.domain.Product;
import com.mphasis.proxy.ProductServiceProxy;

@RestController
public class ProductClientController {

	@Autowired
	private ProductServiceProxy productServiceProxy;
	
	@GetMapping(value = "/get-products/{id}",
			produces = {MediaType.APPLICATION_JSON_VALUE})
	public Product getProductById(@PathVariable("id") Integer id) {
		
		Product product = productServiceProxy.getProductById(id);
		return product;
	}
	
	@GetMapping(value = "/get-products",
			produces = {MediaType.APPLICATION_JSON_VALUE})
	public List<Product> getAllProducts() {
		
		List<Product> products = productServiceProxy.getAllProducts();
		return products;
	}
}
