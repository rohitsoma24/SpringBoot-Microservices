package com.mphasis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceconsumerEurekaRibbonApplicationTests {

	@Test
	void contextLoads() {
	}

}
