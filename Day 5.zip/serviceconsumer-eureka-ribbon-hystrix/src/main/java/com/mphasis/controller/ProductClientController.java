package com.mphasis.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.domain.Product;
import com.mphasis.service.ProductService;

@RestController
public class ProductClientController {

	@Autowired
	private ProductService productService;
	
	@GetMapping(value = "/get-products/{id}",
			produces = {MediaType.APPLICATION_JSON_VALUE})
	public Product getProductById(@PathVariable("id") Integer id) {
		
		return productService.getProductById(id);
	}
}
