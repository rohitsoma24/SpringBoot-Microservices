package com.mphasis.service;

import java.util.List;

import com.mphasis.domain.Product;

public interface IProductService {

	Product addProduct(Product product);

	Product updateProduct(Product product);
	
	Product getProductById(Integer id);
	
	List<Product> getAllProducts();
	
	void deleteProductById(Integer id);
}
