package com.mphasis.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.mphasis.domain.Product;

@RestController
public class ProductClientController {

	@Autowired
	private RestTemplate restTemplate;
	
	@GetMapping(value = "/get-products/{id}",
			produces = {MediaType.APPLICATION_JSON_VALUE})
	public Product getProductById(@PathVariable("id") Integer id) {
		
		// RestTemplate restTemplate = new RestTemplate();
		Product product = restTemplate.getForObject(
				"http://product-service/products/" + id,
				Product.class);
		return product;
	}
}
